ITCS461_Computer and Communication Security
Final Project: Watermarking
___________________________________________
Team member:
Kittinun Aukkapinyo	5888006 sec.1
Parintorn Pooyoi	5888149	sec.1
Suchakree Sawangwong	5888170	sec.1
___________________________________________
How to use:
1. Open "watermarking.exe" file
2. Click "load image" button in row of Image and then select image that you want
   (in "images" folder has 2 files are image_jpg.jpg and image_png.png for using)
3. Click "load image" button in row of Watermark and then select Watermark that you want
   (in "images" folder has 1 file is watermark_png.png for using)
4. If user want input text into the image, type the text that you want
5. Change watermark and text position
6. (optional) Click "Show" button for checking the image
7. Click "Save" button for saving the image (in local path of "watermarking.exe" file)
___________________________________________
